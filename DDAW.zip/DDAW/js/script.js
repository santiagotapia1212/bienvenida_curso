function mostrarBienvenida() {
    alert("Bienvenidos al curso");
}

